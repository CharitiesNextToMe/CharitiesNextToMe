
<!DOCTYPE html>
<link rel="stylesheet" href="https://pyscript.net/alpha/pyscript.css" />
<script defer src="https://pyscript.net/alpha/pyscript.js"></script>
  <style>
    input[type=text], select {
      width: 30%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
      color: black;
    }
    
    input[type=submit] {
      width: 30%;
      background-color: #4c4faf;
      color: black;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    
    input[type=submit]:hover {
      background-color: #45a049;
    }
    
    p {
      text-align: justify;
    }

    
    *{margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family:'Montserrat', sans-serif;
    }
    
    
} 
    </style>
<html lang="en">
<head>
  <meta name = "viewport" content = "width=device-width, initial-scale=1.0">

  
<title>CharitiesNextToMe</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="templates/searchbarcss.css"
<style>
body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif}
.w3-bar,h1,button {font-family: "Montserrat", sans-serif}
.fa-anchor,.fa-coffee {font-size:200px}
</style>
</head>
<body>

<!-- Navbar -->
<div class="w3-top">
  <div class="w3-bar w3-white w3-card w3-left-align w3-large">
    <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-white
      " href="javascript:void(0);" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="#" class="w3-bar-item w3-button w3-padding-large w3-white">Home</a>
    <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white">About me </a>
  </div>

  <!-- Navbar on small screens -->
  <div id="navDemo" class="w3-bar-block w3-white w3-hide w3-hide-large w3-hide-medium w3-large">
    <a href="#" class="w3-bar-item w3-button w3-padding-large">A</a>

  </div>
</div>


<!-- Header -->
  
  
<header class="w3-container w3-white w3-center" style="padding:128px 16px">
  <h1 class="w3-margin w3-jumbo">CharitiesNextToMe</h1>
 





<body>
<div class="container">

  <script type="text/javascript">
    function active(){
      var searchBar = document.getElementById('searchBar');
      if(searchBar.value == 'Search...'){
        searchBar.value=''
        searchBar.placeholder = 'Search...'
      }
    }
  </script>
  <form action="site.php" method ="post" class="search-bar">
    <input type="text" id = "searchBar" placeholder="" value="Search..." name = "search" maxlength="25" autocomplete="off" onmousedown="active()" onblur=""/>
    <button type="submit"><i class="fa fa-search"></i></button>
    <?php
    if (isset($_POST['submit_search'])){
      $search = mysqli_real_escape_string($conn, $_POST['search']);
      $sql = "SELECT* FROM mytable WHERE city LIKE '%search%'";
      $result = mysqli_query($conn, $sql);

      
    }
      
    $sql = "SELECT* FROM mytable WHERE city = 'WETASKIWIN';";
    $result = mysqli_query($conn, $sql);
    $result_check = mysqli_num_rows($result);
    


  </form>
</div>








  


   
<!-- First Grid -->

  
<div class="w3-row-padding w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-twothird">
      <h1>Objectif</h1>
      <h5>
<p>
  Ce site est le projet personnel de Simon Gonzalez il vise a promouvoir des charités locales partout au travers du monde. Ce site est purement charitatif et non lucratif.
</p>
        

</h5>

      <h6>
<p>
  Ce site est le fruit de beacoup d'effort et je tient a remercier w3school pour leur incroyable enseignement en html et pyscript me permettant de faire usage de mes compétences en python directement dans le code html.

</p> </h6>  
    </div>

    <div class="w3-third w3-center">
      <div style = "position:relative; left:75px;">
      <img src="https://images.unsplash.com/photo-1509099836639-18ba1795216d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OXx8Y2hhcml0eXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" width="1400" height="5000">
      </div>
        
    </div>
  </div>
</div>

<!-- Second Grid -->
<div class="w3-row-padding w3-light-grey w3-padding-64 w3-container">
  <div class="w3-content">
    <div class="w3-third w3-center">
      <div style = "position:relative; top:125px;">

      <img src="https://www.cpacanada.ca/-/media/cpa-digital-hub/featured-images/2019/12/hub_12_18_charity-hero-1200x900.jpg?la=en&hash=9F8565E4F74F5F214F4718D3FF427361C02C99C9" width="1400" height="5000">
      </div>

</div>

    <div class="w3-twothird">
      <h1>Poème charité de Jean Aicard</h1>
      <h5 class="w3-padding-32">Si vous croyez que j'ai l'âme assez abaissée <br>
  Pour porter vos dédains sans me lever un jour<br>
  Si vous croyez en moi tuer toute pensée,<br>
  Et sous la haine froide engloutir mon amour,<br>

  Détrompez-vous ! Sans fin je m'élève, je monte !<br>
  Pour vous voir par-dessus l'épaule, humiliés,<br>
  Moi, je n'ai pas besoin, comme vous, dans la honte,<br>
  De me hisser, furtif, sur la pointe des pieds.<br>

  Je vais à l'Idéal, dans un élan suprême !<br>
  Mais vous êtes si bas, je vous en avertis,<br>
  Qu'on ne peut parmi vous rester, bien qu'on vous aime,<br>
  Ni, lorsqu'on se fait grand, vous faire moins petits.</h5>

      
    </div>
  </div>
</div>

<div class="w3-container w3-black w3-center w3-opacity w3-padding-64">
    <h1 class="w3-margin w3-xlarge">Citation du jour: Hier est l'histoire, demain est un mystère, mais aujourd'hui est un cadeau, c'est pour cela qu'il s'appelle le présent</h1>
</div>

<!-- Footer -->
<footer>
</footer>

<script>
// Used to toggle the menu on small screens when clicking on the menu button
function myFunction() {
  var x = document.getElementById("navDemo");
  if (x.className.indexOf("w3-show") == -1) {
    x.className += " w3-show";
  } else { 
    x.className = x.className.replace(" w3-show", "");
  }
}
</script>

</body>
</html>



